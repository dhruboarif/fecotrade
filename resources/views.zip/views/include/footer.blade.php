<footer class="footer" style="background-color: black">
    <div class="w-100 clearfix">
        <span class="text-center text-secondary text-sm-left d-md-inline-block">
        	v3.2.0 {{ __('Copyright © '.date("Y"))}} <a href="https://fecotrade.com" class="text-white">Fecotrade</a>
        	<i class="fa fa-heart text-danger"></i>
        </span>
        <span class="float-none float-sm-right mt-1 mt-sm-0 text-center text-secondary">
        	{{ __('Developed by')}}
        	<a href="https://fecotrade.com" class="text-white" target="_blank">
        		{{ __('FecoTech Solutions')}}
        	</a>
        </span>
    </div>
</footer>
