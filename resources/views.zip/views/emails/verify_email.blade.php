<!DOCTYPE html>
<html>
<head>
    <title>Email Verification</title>
    <style>
        /* Your CSS styles go here */
    </style>
</head>
<body>
    <h2>Hello, Tteeeeeeeeeeeeeeest !</h2>
    <p>Please click on the button below to verify your email address:</p>
    <a href="{{ $actionUrl }}" style="background-color: #3490dc; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Verify Email</a>
    <p>If you did not create an account on our website, you can ignore this email.</p>
</body>
</html>
