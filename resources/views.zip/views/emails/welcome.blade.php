<!DOCTYPE html>
<html>
<head>
    <title>Welcome to Our Website!</title>
</head>
<body>
    <h1>Welcome</h1>
    <p>Thank you for signing up on our website.</p>
    <!-- Add more content here as needed -->
</body>
</html>
