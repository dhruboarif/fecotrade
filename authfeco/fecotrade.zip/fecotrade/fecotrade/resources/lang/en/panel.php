<?php

return [
    'site_title' => 'fecotrade',

];
